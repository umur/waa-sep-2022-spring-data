package edu.miu.lab3springdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab3SpringDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
