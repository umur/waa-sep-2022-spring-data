package edu.miu.lab3springdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab3SpringDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab3SpringDataApplication.class, args);
	}

}
